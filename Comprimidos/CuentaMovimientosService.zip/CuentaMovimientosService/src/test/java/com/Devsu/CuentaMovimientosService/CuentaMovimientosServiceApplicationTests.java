package com.Devsu.CuentaMovimientosService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuentaMovimientosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
