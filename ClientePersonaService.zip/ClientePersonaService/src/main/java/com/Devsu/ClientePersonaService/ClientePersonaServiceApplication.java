package com.Devsu.ClientePersonaService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientePersonaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientePersonaServiceApplication.class, args);
	}

}
