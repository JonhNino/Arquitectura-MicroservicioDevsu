package com.example.common_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
